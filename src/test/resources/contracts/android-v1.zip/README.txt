Private business data. UTF-8 CSV; \N=null. KES integer minor units. records.jsonl is required for lossless typed import. Attachments excluded. Store safely.
